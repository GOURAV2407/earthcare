<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<center>
		<?php 
		    $servername="localhost";
		    $username="root";
		    $password="";
		    $db="contact";
		    $conn=new mysqli("localhost","root","","contact");

		    if ($conn->connect_error) 
		    {
		    	die("Connection failed :".$conn->connect_error);
		    }
		 //echo "Connected successfully....!";
		?>    
	</center>
</body>
</html>