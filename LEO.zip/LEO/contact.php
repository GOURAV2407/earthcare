
 <!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>Earthcare - Environmental & Nature </title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600&family=Roboto&display=swap" rel="stylesheet"> 

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

        <!-- Libraries Stylesheet -->
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
        <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">


        <!-- Customized Bootstrap Stylesheet -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>

        <!-- Spinner Start -->
        <div id="spinner" class="show w-100 vh-100 bg-white position-fixed translate-middle top-50 start-50  d-flex align-items-center justify-content-center">
            <div class="spinner-grow text-primary" role="status"></div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar start -->
        <div class="container-fluid fixed-top px-0">
            <div class="container px-0">
                <div class="topbar">
                                        <div class="row align-items-center justify-content-center">
                        <div class="col-md-8">
                            <div class="topbar-info d-flex flex-wrap">
                                <a href="mailto:gouravpatil2407@gmail.com" class="text-light me-4"><i class="fas fa-envelope text-white me-2"></i>gouravpatil2407@gmail.com</a>
                                <a href="tel:+917499935788" class="text-light"><i class="fas fa-phone-alt text-white me-2"></i>7499935788</a>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="topbar-icon d-flex align-items-center justify-content-end">
                                <a href="https://www.instagram.com/gourav_patil_023/" class=" text-light me-4"><i class="fab fa-instagram"></i> gourav_patil_023</a>
                               
                            </div>
                        </div>
                    </div>
                </div>
                <nav class="navbar navbar-light bg-light navbar-expand-xl">
                    <a href="profile.html" class="navbar-brand ms-3">
                        <h1 class="text-primary display-5">Earthcare</h1>
                    </a>
                    <button class="navbar-toggler py-2 px-3 me-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars text-primary"></span>
                    </button>
                    <div class="collapse navbar-collapse bg-light" id="navbarCollapse">
                         <div class="navbar-nav ms-auto">
                            <a href="index.html" class="nav-item nav-link">Home</a>
                            <a href="about.html" class="nav-item nav-link ">About</a>
                            <a href="service.html" class="nav-item nav-link">Services</a>
                           <a href="volunteer.html" class="nav-item nav-link">Volunteers</a>
                            
                            <a href="contact.php" class="nav-item nav-link">Contact</a>
                        </div>
                        <div class="d-flex align-items-center flex-nowrap pt-xl-0" style="margin-left: 15px;">
                            <a href="donate.html" class="btn-hover-bg btn btn-primary text-white py-2 px-4 me-3">Donate Now</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Navbar End -->

        <!-- Header Start -->
        <div class="container-fluid bg-breadcrumb">
            <div class="container text-center py-5" style="max-width: 900px;">
                <h3 class="text-white display-3 mb-4">Contact Us</h1>
                <p class="fs-5 text-white mb-4">Help today because tomorrow you may be the one who needs more helping!</p>
                   
            </div>
        </div>
        <!-- Header End -->


        <!-- Contact Start -->
        <div class="container-fluid bg-light py-5">
            <div class="container py-5">
                <div class="contact p-5">
                    <div class="row g-4">
                        <div class="col-xl-5">
                            <h1 class="mb-4">Get in touch</h1>
                            <p class="mb-4">“ Have a question, suggestion, or just want to say hi? We would love to hear from you. Let’s make something amazing together.” </p>
                            <form action="contact.php" method="post">
                                <div class="row gx-4 gy-3">
                                   
    <div class="col-xl-6">
        <input type="text" class="form-control bg-white border-0 py-3 px-4" name="name" placeholder="Your Name">
    </div>
    <div class="col-xl-6">
        <input type="email" class="form-control bg-white border-0 py-3 px-4" name="email" placeholder="Your Email">
    </div>
    <div class="col-xl-6">
        <input type="text" class="form-control bg-white border-0 py-3 px-4" name="mobile_no" placeholder="Your Phone No">
    </div>
    <div class="col-xl-6">
        <input type="text" class="form-control bg-white border-0 py-3 px-4" name="subject" placeholder="Subject">
    </div>
    <div class="col-12">
        <textarea class="form-control bg-white border-0 py-3 px-4" name="message" rows="7" cols="10" placeholder="Your Message"></textarea>
    </div>
   <input type="submit" name="submit" value="submit"><br><br> 



                                </div>
                            </form>
                        </div>
                        <div class="col-xl-7">
                            <div>
                                <div class="row g-4">
                                    <div class="col-lg-4">
                                        <div class="bg-white p-4">
                                            <i class="fas fa-map-marker-alt fa-2x text-primary mb-2"></i>
                                            <h4>Address</h4>
                                            <p class="mb-0">Kumbhoj</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="bg-white p-4">
                                            <i class="fas fa-phone-alt fa-2x text-primary mb-2"></i>
                                            <h4>Mail Us</h4>
                                            <p class="mb-0">gp435578@gmail.com</p>
                                            
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="bg-white p-4">
                                            <i class="fas fa-phone-alt fa-2x text-primary mb-2"></i>
                                            <h4>Telephone</h4>
                                            <p class="mb-0">7499935788</p>
                                            <p class="mb-0">9552385986</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387191.33750346623!2d74.2257!3d16.6876!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdc69bc0d0d6781%3A0x10e4232b9ed3c72d!2sKumbhoj%2C%20Hatkanangale%2C%20Kolhapur%2C%20Maharashtra%2C%20India!5e0!3m2!1sen!2sin!4v1688005892654!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Contact End -->


        
        

        <!-- Copyright Start -->
        <div class="container-fluid copyright py-4">
            <div class="container">
                <div class="row g-4 align-items-center">
                    <div class="col-md-4 text-center text-md-start mb-md-0">
                        <span class="text-body"><a href="#"><i class="fas fa-copyright text-light me-2"></i>2025 gourav patil </a> All right reserved.</span>
                    </div>
                   
                    <div class="col-md-4  text-md-end text-body">
                         Designed By Gourav Patil 
                    </div>
                </div>
            </div>
        </div>
        <!-- Copyright End -->



        <!-- Back to Top -->
        <a href="#" class="btn btn-primary btn-primary-outline-0 btn-md-square back-to-top"><i class="fa fa-arrow-up"></i></a>   

        
        <!-- JavaScript Libraries -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/counterup/counterup.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="lib/lightbox/js/lightbox.min.js"></script>
        

        <!-- Template Javascript -->
        <script src="js/main.js"></script>

    </body>

</html>
<?php 
include 'conn_db.php'; 

if (isset($_POST['submit']))
 {
    $name= $_POST['name'];
    $email= $_POST['email'];
    $mobile_no= $_POST['mobile_no'];
    $subject= $_POST['subject'];
    $message= $_POST['message'];


    $stmt = $conn->prepare("INSERT INTO sub (name, email, mobile_no, subject, message) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $mobile_no, $subject, $message);

    if ($stmt->execute()) {
    
        echo "<script> window.location.replace('thank_you.html');</script>";
    } else {
        echo "Oops! Something went wrong 😢: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
